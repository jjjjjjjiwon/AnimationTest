using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

/// <summary>
/// 스테이지 씬 로드 및 클리어 관리
/// </summary>
public class StageManager : MonoBehaviour
{
    public static StageManager Instance { get; private set; }

    private StageData currentStage;

    [Header("Clear Condition")]
    private ClearConditionType clearCondition;  // ⭐ [SerializeField] 제거!
    private int targetKillCount;                 // ⭐ [SerializeField] 제거!
    
    [Header("References")]
    [SerializeField] private Portal portal;        // 포탈 참조

    private int currentKillCount = 0;

    // ⭐ enum 정의 제거! (StageData.cs에 있음)

    // ========================================
    // 싱글톤
    // ========================================

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        StartCoroutine(InitializeStage());
    }

    IEnumerator InitializeStage()
    {
        yield return null;

        if (currentStage == null && GameData.Instance != null)
        {
            currentStage = GameData.Instance.GetStageByFloor(1);

            if (currentStage != null)
            {
                if (RuntimeManager.Instance != null)
                {
                    RuntimeManager.Instance.PrepareFloor(currentStage.stageID);
                    Debug.Log($"[StageManager] 초기화 시 층 {currentStage.stageID} 준비 - 보스: {RuntimeManager.Instance.currentBossName}");
                }
            }
        }
    }

    // ========================================
    // 스테이지 로드
    // ========================================

    /// <summary>스테이지 씬 로드</summary>
    public void LoadStage(StageData stageData)
    {
        if (stageData == null)
        {
            Debug.LogError("[StageManager] StageData가 null입니다!");
            return;
        }

        if (string.IsNullOrEmpty(stageData.sceneName))
        {
            Debug.LogError($"[StageManager] {stageData.stageName}의 sceneName이 비어있습니다!");
            return;
        }

        // 현재 스테이지 저장
        currentStage = stageData;

        // ⭐ 클리어 조건 설정!
        clearCondition = stageData.clearConditionType;
        targetKillCount = stageData.targetKillCount;
        currentKillCount = 0;  // 카운트 초기화!

        Debug.Log($"[StageManager] 씬 로드: {stageData.sceneName}");
        Debug.Log($"[StageManager] 클리어 조건: {clearCondition}, 목표: {targetKillCount}");

        // 보스 정보 설정
        if (RuntimeManager.Instance != null)
        {
            RuntimeManager.Instance.PrepareFloor(stageData.stageID);
            Debug.Log($"[StageManager] 층 {stageData.stageID} 준비 완료 - 보스: {RuntimeManager.Instance.currentBossName}");
        }

        // 씬 로드
        SceneManager.LoadScene(stageData.sceneName);
    }

    // ========================================
    // 적 처치 카운트
    // ========================================

    /// <summary>적 처치 시 호출</summary>
    public void OnEnemyKilled()
    {
        currentKillCount++;

        Debug.Log($"[StageManager] 적 처치: {currentKillCount}/{targetKillCount}");

        // 클리어 조건 체크
        CheckClearCondition();
    }

    private void CheckClearCondition()
    {
        Debug.Log($"[CheckClearCondition] 조건: {clearCondition}, 카운트: {currentKillCount}/{targetKillCount}");

        bool cleared = false;

        switch (clearCondition)
        {
            case ClearConditionType.KillAll:
                int remainingEnemies = FindObjectsOfType<EnemyController>().Length;
                Debug.Log($"[KillAll] 남은 적: {remainingEnemies}");
                if (remainingEnemies == 0)
                    cleared = true;
                break;

            case ClearConditionType.KillTarget:
                Debug.Log($"[KillTarget] {currentKillCount} >= {targetKillCount}?");
                if (currentKillCount >= targetKillCount)
                    cleared = true;
                break;

            case ClearConditionType.Boss:
                Debug.Log("[Boss] 보스 모드");
                break;
        }

        Debug.Log($"[CheckClearCondition] Cleared: {cleared}");

        if (cleared)
        {
            ActivatePortal();
        }
    }

    /// <summary>포탈 활성화</summary>
    public void ActivatePortal()
    {
        if (portal != null)
        {
            portal.Activate();
            Debug.Log("[StageManager] 포탈 활성화!");
        }
        else
        {
            Debug.LogWarning("[StageManager] Portal 참조가 없습니다!");
        }
    }

    // ========================================
    // 스테이지 클리어
    // ========================================

    /// <summary>스테이지 클리어 처리 (Portal에서 호출)</summary>
    public void OnStageCleared()
    {
        if (currentStage == null)
        {
            Debug.LogError("[StageManager] currentStage가 null입니다!");
            return;
        }

        Debug.Log($"[StageManager] 스테이지 클리어: {currentStage.stageName}");

        // 보상 지급 + UI 표시
        RuntimeManager.Instance.GiveReward(currentStage);
    }

    // ========================================
    // 로비 복귀
    // ========================================

    /// <summary>로비로 돌아가기</summary>
    public void LoadLobby()
    {
        Debug.Log("[StageManager] 로비로 복귀");
        SceneManager.LoadScene("Lobby");
    }
}